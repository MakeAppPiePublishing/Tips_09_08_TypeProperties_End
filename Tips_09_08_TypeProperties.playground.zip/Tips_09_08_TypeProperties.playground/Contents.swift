import UIKit
import PlaygroundSupport

extension UIColor{
    static var midGreen:UIColor{
        let interfaceStyle = UIScreen.main.traitCollection.userInterfaceStyle
        return self.init(red: 0, green: interfaceStyle == .dark ? 0.33 :0.66, blue: 0, alpha: 1.0)
    }
    
    
}

class ViewController1:UIViewController{
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = UIColor.midGreen
        self.view = view
    }
}
let vc = ViewController1()
PlaygroundPage.current.liveView = vc

class MyClass{
    //: Instance Constants and variables 
    var instanceVariable = 3
    let instanceConstant = 2
    //: Make these type variables by prefixing with `static` 
    static let typeConstant = 5
    static var typeVariable = 6
    static var typeComputedVariable:Int{
        typeVariable * 2
    }
}

let a = MyClass()
a.instanceConstant 
a.instanceVariable
MyClass.typeConstant
MyClass.typeVariable
MyClass.typeVariable += 1
MyClass.typeVariable








